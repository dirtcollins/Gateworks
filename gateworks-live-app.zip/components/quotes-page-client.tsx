"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import type { FormEvent } from "react";
import { useState } from "react";
import {
  ArrowRight,
  CalendarDays,
  FileText,
  Pencil,
  Plus,
  Search,
  Trash2
} from "lucide-react";
import { useQuoteStore } from "@/lib/quote-store";
import { formatCurrency } from "@/lib/utils";

const taxRate = 0.0825;
const dateFormatter = new Intl.DateTimeFormat("en-US", {
  month: "short",
  day: "numeric",
  year: "numeric"
});

function formatDate(date: string) {
  return dateFormatter.format(new Date(date));
}

function quoteSubtotal(items: { price: number; quantity: number }[]) {
  return items.reduce((total, item) => total + item.price * item.quantity, 0);
}

function quoteTotal(items: { price: number; quantity: number }[]) {
  const subtotal = quoteSubtotal(items);
  const estimatedTax = subtotal * taxRate;
  const deliveryFee = subtotal >= 100 || subtotal === 0 ? 0 : 14.95;

  return subtotal + estimatedTax + deliveryFee;
}

export function QuotesPageClient() {
  const router = useRouter();
  const [quoteName, setQuoteName] = useState("");
  const [editingQuoteId, setEditingQuoteId] = useState("");
  const [editingQuoteName, setEditingQuoteName] = useState("");
  const [query, setQuery] = useState("");
  const { quotes, createQuote, deleteQuote, renameQuote, setActiveQuote } =
    useQuoteStore();

  const filteredQuotes = quotes.filter((quote) => {
    const search = query.trim().toLowerCase();

    if (!search) {
      return true;
    }

    return [
      quote.name,
      quote.quoteNumber,
      quote.invoiceNumber,
      quote.customerName,
      quote.customerEmail,
      quote.status
    ]
      .filter(Boolean)
      .some((value) => String(value).toLowerCase().includes(search));
  });

  function handleCreateQuote(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const quoteId = createQuote(quoteName || "New invoice");
    setActiveQuote(quoteId);
    setQuoteName("");
    router.push(`/quotes/${quoteId}`);
  }

  function startRenamingQuote(quoteId: string, name: string) {
    setEditingQuoteId(quoteId);
    setEditingQuoteName(name);
  }

  function finishRenamingQuote() {
    if (!editingQuoteId) {
      return;
    }

    renameQuote(editingQuoteId, editingQuoteName);
    setEditingQuoteId("");
    setEditingQuoteName("");
  }

  function cancelRenamingQuote() {
    setEditingQuoteId("");
    setEditingQuoteName("");
  }

  const openBalance = quotes.reduce((total, quote) => total + quoteTotal(quote.items), 0);
  const draftCount = quotes.filter((quote) => (quote.status || "draft") === "draft").length;

  return (
    <main className="px-3 py-4 md:px-6 md:py-6">
      <section className="mx-auto max-w-[1280px] rounded-lg border border-black/10 bg-white/86 p-4 shadow-sm backdrop-blur-xl md:p-5">
        <div className="grid gap-4 lg:grid-cols-[1fr_420px] lg:items-end">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.12em] text-industrial-muted">
              Sales documents
            </p>
            <h1 className="mt-1 text-3xl font-semibold text-industrial-ink">
              Invoices and quotes
            </h1>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-industrial-muted">
              Create the document first, choose the customer, add products and services,
              review totals, then save or send.
            </p>
          </div>

          <form className="rounded-lg border border-black/10 bg-[#f7f7f4] p-2" onSubmit={handleCreateQuote}>
            <label className="sr-only" htmlFor="quote-name">
              New invoice name
            </label>
            <div className="flex gap-2">
              <input
                className="h-11 min-w-0 flex-1 rounded-lg border border-transparent bg-white px-3 text-sm text-industrial-ink outline-none focus:border-black/10"
                id="quote-name"
                placeholder="Customer, job, or invoice name"
                value={quoteName}
                onChange={(event) => setQuoteName(event.target.value)}
              />
              <button
                className="inline-flex h-11 items-center gap-2 rounded-lg bg-industrial-ink px-4 text-sm font-semibold text-white"
                type="submit"
              >
                <Plus size={18} />
                New
              </button>
            </div>
          </form>
        </div>
      </section>

      <section className="mx-auto mt-4 grid max-w-[1280px] gap-3 md:grid-cols-3">
        <Metric label="Open balance" value={formatCurrency(openBalance)} />
        <Metric label="Drafts" value={String(draftCount)} />
        <Metric label="Documents" value={String(quotes.length)} />
      </section>

      <section className="mx-auto mt-4 max-w-[1280px] overflow-hidden rounded-lg border border-black/10 bg-white/86 shadow-sm backdrop-blur-xl">
        <div className="flex flex-col gap-3 border-b border-black/10 bg-[#fafaf8] p-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="text-base font-semibold text-industrial-ink">Documents</h2>
            <p className="text-sm text-industrial-muted">Quotes can become invoices after review.</p>
          </div>
          <label className="relative block md:w-80">
            <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-industrial-muted" size={16} />
            <input
              className="h-10 w-full rounded-lg border border-black/10 bg-white pl-9 pr-3 text-sm text-industrial-ink outline-none"
              placeholder="Search customer or invoice"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
            />
          </label>
        </div>

        <div className="hidden grid-cols-[1.2fr_1fr_120px_130px_150px] gap-3 border-b border-black/10 px-4 py-3 text-xs font-semibold uppercase tracking-[0.08em] text-industrial-muted lg:grid">
          <span>Document</span>
          <span>Customer</span>
          <span>Status</span>
          <span className="text-right">Balance</span>
          <span className="text-right">Actions</span>
        </div>

        <div className="divide-y divide-black/10">
          {filteredQuotes.map((quote) => {
            const total = quoteTotal(quote.items);
            const totalQuantity = quote.items.reduce(
              (itemCount, item) => itemCount + item.quantity,
              0
            );
            const invoiceNumber = quote.invoiceNumber || quote.quoteNumber;
            const status = quote.status || "draft";

            return (
              <article key={quote.id} className="grid gap-3 p-4 transition hover:bg-[#fafaf8] lg:grid-cols-[1.2fr_1fr_120px_130px_150px] lg:items-center">
                <div>
                  <div className="flex flex-wrap items-center gap-2 text-xs font-semibold uppercase tracking-[0.08em] text-industrial-muted">
                    <span>{invoiceNumber}</span>
                    <span>|</span>
                    <span className="inline-flex items-center gap-1">
                      <CalendarDays size={14} />
                      Due {formatDate(quote.dueAt || quote.expiresAt)}
                    </span>
                  </div>
                  <div className="mt-2 flex max-w-xl items-center gap-2">
                    {editingQuoteId === quote.id ? (
                      <input
                        aria-label={`Rename ${quote.name}`}
                        autoFocus
                        className="h-10 min-w-0 flex-1 rounded-lg border border-black/10 bg-white px-2 text-lg font-semibold text-industrial-ink outline-none"
                        value={editingQuoteName}
                        onBlur={finishRenamingQuote}
                        onChange={(event) => setEditingQuoteName(event.target.value)}
                        onKeyDown={(event) => {
                          if (event.key === "Enter") {
                            event.currentTarget.blur();
                          }

                          if (event.key === "Escape") {
                            event.preventDefault();
                            cancelRenamingQuote();
                          }
                        }}
                      />
                    ) : (
                      <>
                        <h3 className="min-w-0 truncate text-lg font-semibold text-industrial-ink">
                          {quote.name}
                        </h3>
                        <button
                          aria-label={`Rename ${quote.name}`}
                          className="grid size-8 shrink-0 place-items-center rounded-lg border border-black/10 bg-white text-industrial-muted transition hover:text-industrial-ink"
                          type="button"
                          onClick={() => startRenamingQuote(quote.id, quote.name)}
                        >
                          <Pencil size={15} />
                        </button>
                      </>
                    )}
                  </div>
                  <p className="mt-1 text-sm text-industrial-muted">
                    {totalQuantity} line item{totalQuantity === 1 ? "" : "s"}
                  </p>
                </div>

                <div>
                  <p className="text-sm font-medium text-industrial-ink">
                    {quote.customerName || "No customer selected"}
                  </p>
                  <p className="text-xs text-industrial-muted">
                    {quote.customerEmail || "Add email before sending"}
                  </p>
                </div>

                <span className="w-fit rounded-full border border-black/10 bg-white px-2.5 py-1 text-xs font-semibold uppercase tracking-[0.08em] text-industrial-muted">
                  {status}
                </span>

                <p className="text-left text-xl font-semibold text-industrial-ink lg:text-right">
                  {formatCurrency(total)}
                </p>

                <div className="flex gap-2 lg:justify-end">
                  <Link
                    className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-industrial-ink px-3 text-sm font-semibold text-white"
                    href={`/quotes/${quote.id}`}
                    onClick={() => setActiveQuote(quote.id)}
                  >
                    Open
                    <ArrowRight size={16} />
                  </Link>
                  <button
                    aria-label={`Delete ${quote.name}`}
                    className="grid size-10 place-items-center rounded-lg border border-black/10 text-industrial-muted transition hover:border-red-700 hover:text-red-700"
                    type="button"
                    onClick={() => deleteQuote(quote.id)}
                  >
                    <Trash2 size={17} />
                  </button>
                </div>
              </article>
            );
          })}
        </div>

        {!filteredQuotes.length ? (
          <div className="grid place-items-center p-10 text-center">
            <FileText size={28} />
            <p className="mt-3 text-lg font-semibold text-industrial-ink">No matching documents.</p>
          </div>
        ) : null}
      </section>
    </main>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-black/10 bg-white/78 p-4 shadow-sm backdrop-blur-xl">
      <p className="text-xs font-semibold uppercase tracking-[0.1em] text-industrial-muted">{label}</p>
      <p className="mt-1 text-2xl font-semibold text-industrial-ink">{value}</p>
    </div>
  );
}
